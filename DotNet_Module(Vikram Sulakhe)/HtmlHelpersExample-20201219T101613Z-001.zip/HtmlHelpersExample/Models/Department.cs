﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HtmlHelpersExample.Models
{
    public class Department
    {
        public int DeptNo { get; set; }
        public string DeptName { get; set; }
    }
}